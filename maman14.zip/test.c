/*
 * =====================================================================================
 *
 *       Filename:  test.c
 *
 *    Description: Gi
 *
 *        Version:  1.0
 *        Created:  08/14/2021 04:41:41 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (),
 *   Organization:
 *
 * =====================================================================================
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
/* #include "labels.c" */
/* #include "encoder.c" */
/* #include "utils.c" */
#include <ctype.h>


#define SetBit(A,k)     ( A[(k/32)] |= (1 << (k%32)) )
#define ClearBit(A,k)   ( A[(k/32)] &= ~(1 << (k%32)) )
#define TestBit(A,k)    ( A[(k/32)] & (1 << (k%32)) )

/* void print_bitmap_32(BITMAP_32 *bitmap){ */
/*     int i; */
/*     int bit; */

/*     for (i=1; i <= 31; i++){ */
/*         bit = TestBit(*bitmap, i); */
/*         bit ? printf("1") : printf("0"); */
/*     } */
/*     printf("\n"); */
/* } */

/* void add_obj_to_bitmap(int obj, int *start_ix, int size, BITMAP_32 *bitmap){ */
/*     int bit_shift; */
/*     for (bit_shift = size; bit_shift >= 0; bit_shift--){ */
/*         printf("%d\n", bit_shift); */
/*         /1* Compute the bit and set it in the bitmap *1/ */
/*         if ( ((obj >> bit_shift) & 1) == 1 ){ */
/*             printf("Set bit %d\n", *start_ix); */
/*             SetBit(*bitmap, *start_ix); */
/*         } */

/*         (*start_ix)++; */

/*     } */
/* } */

int main(int argc, char *argv[])
{

    /* ix = 0; */
    /* bitmap = (BITMAP_32 *) calloc(1, sizeof(BITMAP_32)); */

    /* add_obj_to_bitmap(a, &ix, 8, bitmap); */
    /* print_bitmap_32(bitmap); */
    /* printf("Letter: %02X\n", a); */
    /* dump_bitmap(bitmap, "/tmp/test.bin", 100); */
	int i,j;
	int size = 16;
	int val = 27056;

	int byte[8];
	int byte_ix;
	int bit;

	byte_ix = 0;

	for(i = 0; i <= size-1; i++ ){
        byte[byte_ix++] = ((val >>i) & 1);

		if (byte_ix == 8){
			byte_ix = 0;
			for (j=7; j >= 0; j--){
				printf("%d", byte[j]);
				byte[j] = '0';
			}
			printf("-");
		}
	}

	return 0;
}
