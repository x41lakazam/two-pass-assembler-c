make
./assembler test_file.as test_file2.as
