Two pass assembler
